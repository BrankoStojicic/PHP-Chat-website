=== Wickett Twitter Widget ===
Contributors: automattic, nickmomrik, beaulebens
Tags: twitter, widget, tweets, WordPress.com
Stable tag: trunk
Requires at least: 2.8
Tested up to: 3.0

Display tweets from a Twitter account in the sidebar of your blog. As seen on WordPress.com.

== Installation ==

1. Upload wickett-twitter-widget.php to your /wp-content/plugins/ directory.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. Add the widget to your sidebar from Appearance->Widgets and configure the widget options.

== Frequently Asked Questions ==

= Can multiple instances of the widget be used? =

Yes.

= Can private Twitter accounts be used? =

No.

== Changelog ==

= 1.0 =
* Initial version

= 1.0.1 =
* Rename time_since function to avoid conflicts with other plugins
